# TradePilot Native Android

Native React Native Android client for TradePilot. This is separate from the managed Expo project because Telegram user-account MTProto needs native TDLib binaries.

## Current stack

- React Native 0.87.1 bare Android project
- `react-native-tdlib` with prebuilt TDLib Android binaries
- `react-native-keychain` backed by Android Keystore
- Client-side Bybit V5 HMAC account sync and guarded order path
- Client-side Gemini Flash structured extraction
- Expo-parity dark dashboard with Overview, Calls, Positions, and Settings tabs
- Animated hero balance card, sparkline, connection status rows, signal cards, risk controls, and live-order guard
- Android foreground monitoring service with persistent notification and start/stop controls
- GitHub Actions Gradle APK build

## Local development

The Sandbox used to generate this project does not have Android SDK or Gradle installed, so native compilation must run on a workstation, Android Studio, or GitHub Actions.

```bash
npm ci
npx react-native start
npx react-native run-android
```

## Telegram setup inside the app

1. Go to [my.telegram.org](https://my.telegram.org).
2. Create an application in **API development tools**.
3. Enter the `api_id` and `api_hash` in the app.
4. Enter the Telegram phone number.
5. Start TDLib.
6. Enter the Telegram login code and 2FA password when prompted.
7. Load chats/channels. New messages arrive through TDLib updates.

The TDLib database/session is local to the Android app. API Hash and Telegram session data are sensitive. Do not log them or commit them.

## Bybit and Gemini

Enter API credentials in the app and save them. `react-native-keychain` stores the JSON credential bundle with `WHEN_UNLOCKED_THIS_DEVICE_ONLY`. Use a Bybit key without withdrawal or transfer permissions. The UI starts with live order locked; Mainnet and the Live Order toggle are both required before an order request can be sent.

## GitHub Actions APK

Workflow: `.github/workflows/android.yml`

1. Push this directory to a GitHub repository.
2. Open **Actions → Build TradePilot Native APK**.
3. Run the workflow or push to `main`.
4. Download `TradePilot-native-release-apk` from the completed run.

The workflow produces an unsigned release APK for internal testing. Configure a real Android signing keystore before distributing outside personal testing.

## Background monitoring behavior

The Settings tab can start or stop `TradePilotForegroundService`. Android keeps this service alive with a persistent notification while the app is in the background, and the dashboard exposes the current monitoring state. Android may still stop a service after force-stop, battery restrictions, or a device reboot; production deployments should add explicit battery-optimization guidance and a signed release build.

The service is a monitoring lifecycle layer. TDLib authentication/session data and API credentials remain local to the app; live order execution remains locked until the user explicitly enables the Live Order toggle.
