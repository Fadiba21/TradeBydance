import React from 'react';
import { Text } from 'react-native';
export default function MaterialIcons({ name }: { name: string }) { return <Text>{name}</Text>; }
