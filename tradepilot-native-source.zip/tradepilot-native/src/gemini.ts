export type Signal = { symbol: string; direction: 'LONG' | 'SHORT'; entry: number; stopLoss: number; takeProfit: number; leverage: number; confidence: number; rationale: string };

export async function analyzeSignal(apiKey: string, message: string, model = 'gemini-2.5-flash'): Promise<Signal> {
  if (!apiKey.trim()) throw new Error('Gemini API Key belum diisi.');
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ systemInstruction: { parts: [{ text: 'Extract a crypto futures call. Return JSON only. Do not invent missing values. Use confidence 0 when ambiguous.' }] }, contents: [{ role: 'user', parts: [{ text: message }] }], generationConfig: { temperature: 0, responseMimeType: 'application/json', responseSchema: { type: 'object', properties: { symbol: { type: 'string' }, direction: { type: 'string', enum: ['LONG', 'SHORT'] }, entry: { type: 'number' }, stopLoss: { type: 'number' }, takeProfit: { type: 'number' }, leverage: { type: 'integer' }, confidence: { type: 'number' }, rationale: { type: 'string' } }, required: ['symbol', 'direction', 'entry', 'stopLoss', 'takeProfit', 'leverage', 'confidence', 'rationale'] } } }) });
  const body = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>; error?: { message?: string } };
  if (!response.ok) throw new Error(body.error?.message || `Gemini HTTP ${response.status}`);
  const text = body.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini tidak mengembalikan signal.');
  const signal = JSON.parse(text) as Signal;
  if (signal.confidence < 0.8) throw new Error('Signal ditolak: confidence di bawah 80%.');
  return signal;
}
