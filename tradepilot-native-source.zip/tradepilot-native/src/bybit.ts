import HmacSHA256 from 'crypto-js/hmac-sha256';
import Hex from 'crypto-js/enc-hex';
import type { Credentials } from './security';

const recvWindow = '5000';
const baseUrl = (env: Credentials['bybitEnvironment']) => env === 'mainnet' ? 'https://api.bybit.com' : 'https://api-testnet.bybit.com';

type Envelope<T> = { retCode: number; retMsg: string; result: T };
export type Account = { equity: string; available: string; walletBalance: string };
export type Position = { symbol: string; side: string; size: string; avgPrice: string; unrealisedPnl: string; leverage: string; stopLoss?: string; takeProfit?: string };

async function request<T>(credentials: Credentials, method: 'GET' | 'POST', path: string, params: Record<string, string | number>): Promise<T> {
  if (!credentials.bybitApiKey || !credentials.bybitApiSecret) throw new Error('Bybit API Key dan Secret belum diisi.');
  const timestamp = String(Date.now());
  const query = new URLSearchParams(Object.entries(params).map(([k, v]) => [k, String(v)])).toString();
  const signature = HmacSHA256(`${timestamp}${credentials.bybitApiKey}${recvWindow}${method === 'GET' ? query : JSON.stringify(params)}`, credentials.bybitApiSecret).toString(Hex);
  const response = await fetch(`${baseUrl(credentials.bybitEnvironment)}${path}${method === 'GET' ? `?${query}` : ''}`, { method, headers: { 'Content-Type': 'application/json', 'X-BAPI-API-KEY': credentials.bybitApiKey, 'X-BAPI-TIMESTAMP': timestamp, 'X-BAPI-RECV-WINDOW': recvWindow, 'X-BAPI-SIGN': signature }, body: method === 'POST' ? JSON.stringify(params) : undefined });
  const body = await response.json() as Envelope<T>;
  if (!response.ok || body.retCode !== 0) throw new Error(`Bybit: ${body.retMsg || response.status}`);
  return body.result;
}

export async function fetchAccount(credentials: Credentials): Promise<Account> {
  const result = await request<{ list?: Array<{ totalEquity?: string; totalAvailableBalance?: string; coin?: Array<{ coin: string; walletBalance: string }> }> }>(credentials, 'GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED', coin: 'USDT' });
  const wallet = result.list?.[0];
  const coin = wallet?.coin?.find((entry) => entry.coin === 'USDT');
  return { equity: wallet?.totalEquity || '0', available: wallet?.totalAvailableBalance || '0', walletBalance: coin?.walletBalance || '0' };
}

export async function fetchPositions(credentials: Credentials): Promise<Position[]> {
  const result = await request<{ list?: Position[] }>(credentials, 'GET', '/v5/position/list', { category: 'linear', settleCoin: 'USDT' });
  return (result.list || []).filter((position) => Number(position.size) > 0);
}

export async function placeOrder(credentials: Credentials, input: { symbol: string; side: 'Buy' | 'Sell'; qty: string; takeProfit: string; stopLoss: string; leverage: number; marginMode: 'Cross' | 'Isolated'; liveUnlocked: boolean }) {
  if (!input.liveUnlocked) throw new Error('Live Trading masih terkunci.');
  if (credentials.bybitEnvironment !== 'mainnet') throw new Error('Pilih Bybit Mainnet untuk order live.');
  await request(credentials, 'POST', '/v5/position/set-leverage', { category: 'linear', symbol: input.symbol, buyLeverage: String(input.leverage), sellLeverage: String(input.leverage) });
  await request(credentials, 'POST', '/v5/account/set-margin-mode', { setMarginMode: input.marginMode === 'Cross' ? 'REGULAR_MARGIN' : 'ISOLATED_MARGIN' });
  return request<{ orderId: string; orderLinkId?: string }>(credentials, 'POST', '/v5/order/create', { category: 'linear', symbol: input.symbol, side: input.side, orderType: 'Market', qty: input.qty, positionIdx: 0, orderLinkId: `tradepilot-${Date.now()}`, takeProfit: input.takeProfit, stopLoss: input.stopLoss, tpTriggerBy: 'MarkPrice', slTriggerBy: 'MarkPrice' });
}
