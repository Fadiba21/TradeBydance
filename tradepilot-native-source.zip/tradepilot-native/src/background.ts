import { NativeModules, Platform } from 'react-native';

const native = NativeModules.TradePilotBackground as { start: () => void; stop: () => void } | undefined;

export function startBackgroundMonitoring(): void {
  if (Platform.OS !== 'android' || !native) throw new Error('Background monitoring hanya tersedia di Android native build.');
  native.start();
}

export function stopBackgroundMonitoring(): void {
  native?.stop();
}
