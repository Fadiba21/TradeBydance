import TdLib, { type TdLibUpdateEvent } from 'react-native-tdlib';
import { NativeEventEmitter, NativeModules } from 'react-native';
import type { Credentials } from './security';

const emitter = new NativeEventEmitter(NativeModules.TdLibModule || { addListener: () => undefined, removeListeners: () => undefined } as any);
let subscription: { remove: () => void } | null = null;

export type TelegramChat = { id: number; title: string; type?: { _: string }; username?: string };
export type TelegramMessage = { chatId: number; messageId: number; text: string };
function normalizeAuthState(value: string): string { try { return JSON.parse(value)['@type'] || value; } catch { return value; } }

export async function startTelegram(credentials: Credentials, onMessage: (message: TelegramMessage) => void, onState: (state: string) => void): Promise<void> {
  const apiId = Number(credentials.telegramApiId);
  if (!apiId || !credentials.telegramApiHash) throw new Error('Telegram API ID dan API Hash belum diisi.');
  subscription?.remove();
  subscription = emitter.addListener('tdlib-update', (event: TdLibUpdateEvent | Object) => {
    try {
      const raw = JSON.parse((event as TdLibUpdateEvent).raw) as Record<string, any>;
      if (raw['@type'] === 'updateAuthorizationState') onState(raw.authorization_state?.['@type'] || 'unknown');
      if (raw['@type'] === 'updateNewMessage') {
        const message = raw.message;
        const text = message?.content?.text?.text;
        if (message?.chat_id && text) onMessage({ chatId: Number(message.chat_id), messageId: Number(message.id), text });
      }
    } catch { /* TDLib can emit non-message updates */ }
  });
  await TdLib.startTdLib({ api_id: apiId, api_hash: credentials.telegramApiHash, application_version: 'TradePilot Native 1.0', device_model: 'Android', system_language_code: 'en' });
  onState(normalizeAuthState(await TdLib.getAuthorizationState()));
}

export async function loginTelegram(phoneNumber: string): Promise<void> {
  const normalized = phoneNumber.replace(/\s+/g, '');
  const match = normalized.match(/^(\+\d{1,3})(\d+)$/);
  await TdLib.login({ countrycode: match?.[1] || '+', phoneNumber: match?.[2] || normalized.replace(/^\+/, '') });
}
export async function verifyTelegramCode(code: string): Promise<void> { await TdLib.verifyPhoneNumber(code); }
export async function verifyTelegramPassword(password: string): Promise<void> { await TdLib.verifyPassword(password); }
export async function listTelegramChats(): Promise<TelegramChat[]> { await TdLib.loadChats(100); return JSON.parse(await TdLib.getChats(100)) as TelegramChat[]; }
export async function logoutTelegram(): Promise<void> { await TdLib.logout(); }
