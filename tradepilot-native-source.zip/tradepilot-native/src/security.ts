import * as Keychain from 'react-native-keychain';

const SERVICE = 'com.tradepilotnative.credentials';

export type Credentials = {
  telegramApiId: string;
  telegramApiHash: string;
  bybitApiKey: string;
  bybitApiSecret: string;
  bybitEnvironment: 'testnet' | 'mainnet';
  geminiApiKey: string;
};

const EMPTY: Credentials = { telegramApiId: '', telegramApiHash: '', bybitApiKey: '', bybitApiSecret: '', bybitEnvironment: 'testnet', geminiApiKey: '' };

export async function loadCredentials(): Promise<Credentials> {
  const item = await Keychain.getGenericPassword({ service: SERVICE });
  if (!item) return EMPTY;
  try { return { ...EMPTY, ...JSON.parse(item.password) } as Credentials; } catch { return EMPTY; }
}

export async function saveCredentials(credentials: Credentials): Promise<void> {
  await Keychain.setGenericPassword('tradepilot', JSON.stringify(credentials), { service: SERVICE, accessible: Keychain.ACCESSIBLE.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
}

export async function clearCredentials(): Promise<void> {
  await Keychain.resetGenericPassword({ service: SERVICE });
}
