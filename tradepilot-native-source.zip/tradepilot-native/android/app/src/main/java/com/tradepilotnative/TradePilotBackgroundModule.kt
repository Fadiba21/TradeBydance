package com.tradepilotnative

import android.content.Intent
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class TradePilotBackgroundModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
  override fun getName(): String = "TradePilotBackground"

  @ReactMethod
  fun start() {
    val intent = Intent(reactContext, TradePilotForegroundService::class.java)
    ContextCompat.startForegroundService(reactContext, intent)
  }

  @ReactMethod
  fun stop() {
    reactContext.stopService(Intent(reactContext, TradePilotForegroundService::class.java))
  }
}
