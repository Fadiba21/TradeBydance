module.exports = {
  preset: '@react-native/jest-preset',
  moduleNameMapper: {
    '^react-native-tdlib$': '<rootDir>/__mocks__/react-native-tdlib.ts',
    '^@react-native-vector-icons/material-icons$': '<rootDir>/__mocks__/material-icons.tsx',
  },
};
